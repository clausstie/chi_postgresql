b-PAC README.TXT

This document explains when you should use the two files in this folder.

Note that this version requires the Microsoft Windows Installer, which is
available as standard on Windows ME, 2000 and XP.

For a version of b-PAC that works with Windows 95, 98, 98SE and NT4, obtain
the other version of the b-PAC download. Contact your local Brother office
if you are unable to obtain this other version.

In addition to this readme file, you will find two other files as follows:

bPacSdk.msi
This file contains the developer version of b-PAC. It contains the following:

	b-PAC Software Development Kit
	Sample Files
	Sample Templates
	User Guide/Instructions

Install this version on the PC where your applications will be developed.


bPAC_CCI.msi
This file ONLY contains the files needed to install b-PAC on a client's PC.

It does not contain any sample files, templates or user guides.

Install this on a PC where you only need to the files needed to make your
own program print to a P-touch label printer.

Note that when installed, it will appear nothing has happened. However, the relevent files are installed to the Windows Common Files folder.